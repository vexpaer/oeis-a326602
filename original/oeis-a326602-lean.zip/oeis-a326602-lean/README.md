# OEIS A326602 — Proof and Lean 4 Formalization

**Author:** Ximing Wang (`vexpaer@gmail.com`)  
**Date:** November 27, 2026  
**Target:** [OEIS A326602](https://oeis.org/A326602) (Paul D. Hanna, Aug 8, 2019)

## Summary

We prove Paul D. Hanna's 2019 conjecture on [OEIS A326602](https://oeis.org/A326602) directly from the primary formal power series definition

$$A(x) = \sum_{n=0}^{\infty} \frac{(x^{2n-1}+1)^n x^n}{(1+x^{2n+1})^{n+1}} = \sum_{n=0}^{\infty} \frac{(x^{2n}+x)^n}{(1+x^{2n+1})^{n+1}} \in \mathbb{Z}[[x]],$$

establishing:
1. **Exact Triple-Sum Representation (`coeff_A_eq_triple_sum`):**
   $$[x^N] A(x) = \sum_{\substack{a,b,c \ge 0 \\ a + c + 2(b+a)(b+c) = N}} (-1)^a \frac{(a+b+c)!}{a!\,b!\,c!}.$$
2. **Evenness (`coeff_A_odd_eq_zero`):** $[x^{2n+1}] A(x) = 0$ for all $n \in \mathbb{N}$ via the sign-reversing involution $(a,b,c) \mapsto (c,b,a)$.
3. **Parity Conjecture (`conjecture_parity`):** For all $n \in \mathbb{N}$, $a(n) = [x^{2n}] A(x)$ is odd if and only if $n$ is a perfect square (`Odd (a n) ↔ ∃ b : ℕ, n = b ^ 2`).

## Files Included

- `326602.lean` — Complete Lean 4 (`v4.33.1`) formalization (781 lines, 0 errors, 0 warnings, 0 `sorry`, axioms `[propext, Classical.choice, Quot.sound]` only).
- `oeis_a326602_paper.tex` — LaTeX source of the paper.
- `oeis_a326602_paper.pdf` — Compiled PDF of the paper.
- `README.md` — This file.

## Verification

Place `326602.lean` at `FormalConjectures/OEIS/326602.lean` inside [`google-deepmind/formal-conjectures`](https://github.com/google-deepmind/formal-conjectures) and run:

```bash
lake build FormalConjectures.OEIS.«326602»
```
